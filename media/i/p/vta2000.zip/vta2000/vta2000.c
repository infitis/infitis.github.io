/* -*- mode:c -*- */
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <bios.h>
#include <conio.h>
#include <unistd.h>
#include <dos.h>
#include <graph.h>

//#include "debug.h"
//#include "serio.h"
#include "queue.h"
#include "serial.h"

#define NROWS 24
#define NCOLS 80
#define STRBUFLEN 256
#define BOOL int
#define SERIAL_PORTS 4
#define ESCAPE_CHAR 27
#define _COM_INIT_DRIVER 0x4
#define _COM_DEINIT_DRIVER 0x5

int codepage_no=1; /* codepage number */

/* cyrillic characters for the VTA-2000 terminal */
char mapping[64] =
  {
    0xee, 0xa0, 0xa1, 0xe6, 0xa4, 0xa5, 0xe4, 0xa3,  0xe5, 0xa8, 0xa9, 0xaa, 0xab, 0xac, 0xad, 0xae,
    0xaf, 0xef, 0xe0, 0xe1, 0xe2, 0xe3, 0xa6, 0xa2,  0xec, 0xeb, 0xa7, 0xe8, 0xed, 0xe9, 0xe7, 0xea,
    0x9e, 0x80, 0x81, 0x96, 0x84, 0x85, 0x94, 0x83,  0x95, 0x88, 0x89, 0x8a, 0x8b, 0x8c, 0x8d, 0x8e,
    0x8f, 0x9f, 0x90, 0x91, 0x92, 0x93, 0x86, 0x82,  0x9c, 0x9b, 0x87, 0x98, 0x9d, 0x99, 0x97, /*0x9a*/ 0x7f
  };

/* global variable for a serial status */
unsigned short serial_status=0;

/* number of bytes received successfully */
unsigned long byte_count=0;

static void print_message(char *msg)
{
  struct rccoord pos=_gettextposition(); /* remember current position */
  short r1=0, c1=0, r2=0, c2=0;
  _gettextwindow (&r1, &c1, &r2, &c2); /* remember old window rectangle */

  _settextwindow (NROWS+1, 1, NROWS+1, NCOLS);
  _outtext ("\n");
  _outtext (msg);
  
  _settextwindow (r1, c1, r2, c2);
  _settextposition (pos.row, pos.col);
}

/* checks if data is pending */
static BOOL ComPortDataReady(void)
{
  int serial_status = ComStatus();
  if (serial_status&0x9e00)
    {
      char buf[80];
      sprintf (buf, "Serial status error: serial_status =%08b %08b.", 
	       (serial_status&0xff00)>>8, 
	       serial_status&0x00ff);
      print_message (buf);
    }
  return ((serial_status & 0x0100) != 0);
}

/* reads pending data (port: 1, 2, ...) */
static char ComPortReadData(void)
{
  char c=ComRecChar();
  byte_count++;
  return c;
}

/* waits and then reads data */
static char ComPortReadNext(void)
{
  while (!ComPortDataReady()) {}
  return ComPortReadData();
}

static void beep(void)
{
  putch('\a');
}

static void dispatch_sequence (void)
{
  char c=0;
  struct rccoord pos=_gettextposition(); /* remember current position */

  c = ComPortReadNext();
  if (c==ESCAPE_CHAR)
    {
      for (;;) /* eat and ignore all escapes */
	{
	  c = ComPortReadNext();
	  if (c!=ESCAPE_CHAR)
	    break;
	}
      switch (c)
	{
	case 'A': /* move up */
	  if (pos.row > 1)
	    (void)_settextposition(pos.row-1, pos.col);
	  else
	    beep();
	  break;
	case 'B': /* move down */
	  if (pos.row < NROWS)
	    (void)_settextposition(pos.row+1, pos.col);
	  else
	    beep();
	  break;
	case 'C': /* move right */
	  if (pos.row < NCOLS)
	    (void)_settextposition(pos.row, pos.col+1);
	  else
	    beep();
	  break;
	case 'D': /* move left */
	  if (pos.row > 1)
	    (void)_settextposition(pos.row, pos.col-1);
	  else
	    beep();
	  break;
	case 'F': /* move to the beginning of the new line */
	  if (pos.row==NROWS)
	    _settextposition (1, 1);
	  else
	    _settextposition(pos.row+1, pos.col);	    
	  break;
	case 'G': case 'g': /* move to the beginning of the current line */
	  _settextposition(pos.row, 1);
	  break;
	case 'H': /*case 'Y': (?) */ /* move to the beginning of the screen */
	  _settextposition (1, 1);
	  break;
	case 'Y': /* move to */
	  {
	    char m,n;
	    m = ComPortReadNext() - 0x20+1;
	    n = ComPortReadNext() - 0x20+1;
	    _settextposition(m,n);
	  }
	  break;
	case 'K': /* clear until the end of line */
	  {
	    char buf[NCOLS]={' '};
	    _outmem (buf, NCOLS);
	    _settextposition (pos.row, pos.col);
	  }
	  break;
	case 'J': /* clear until the end of the screen */
	  {
	    char buf[NCOLS]={' '};
	    short row=0;
	    _outmem (buf, NCOLS);
	    for (row=pos.row+1; row<=NROWS; row++) {
	      _settextposition (row, 1);
	      _outmem (buf, NCOLS);
	    }	      
	    _settextposition (pos.row, pos.col);
	  }
	  break;
	case 'E': /* clear the whole screen */
	  _clearscreen (_GWINDOW);
	  break;
	case 'S': /* scroll up */
	  _scrolltextwindow(_GSCROLLUP);
	  break;
	default:
	  beep();
	  //serial_unread_data(port, c);
	}
    }
  else
    {
      switch (c)
	{
	case '\r': /* carriage return */
	  _settextposition(pos.row, 1);
	  break;
	case '\n': /* new line */
	  if (pos.row==NROWS)
	    _scrolltextwindow(_GSCROLLUP);
	  else
	    _settextposition(pos.row+1, pos.col);	    
	  break;
	default:
	  {
	    if ( ((unsigned)c >= 0x40) && codepage_no )
	      c = mapping[(unsigned)c-0x40]; /* cyrillic letter */
	    _outmem (&c, 1); /* display a character */

	    if (pos.col >= NCOLS-1) { /* ">" is impossible */
	      if (pos.row < NROWS) { /* new line */
		_settextposition (pos.row+1, 1);
	      } else { /* scroll up */
		_scrolltextwindow (_GSCROLLUP); 
		_settextposition (NROWS, 1);
	      }
	    }
	  }
	}
    }
}

int main (int argc, char *argv[])
{
  int port=1;
  if (argc != 2)
    {
      fprintf (stderr, "Usage:\n  vta2000.exe port_number\n");
      exit(1);
    }

  port = atoi(argv[1]);
  printf ("VTA-2000 Terminal Emulator, Copyright (c) 2005-2006 Kometa Ltd.\n");
  printf ("Using COM%-u\n", port);
  sleep(3);

  /* Initialize com port */
  if (OpenComPort (argv[1][0])==-1)
    {
      fprintf (stderr, "Error: Cannot open COM port.");
      exit(1);
    }
  InitComPort ( "9600", '8', 'o', '2');

  _setvideomode(_TEXTC80);
  _clearscreen(_GCLEARSCREEN);
  _settextwindow(1,1,NROWS,NCOLS);
  _wrapon(_GWRAPOFF);
  _settextcursor (0x0007); /* full block cursor */
  break_on();

  for (;;)
    {
      if (kbhit())
	{
	  char key=0;
	  key = getch();
	  if (key==ESCAPE_CHAR)
	    break;
	}
      else 
	{
	  if (ComPortDataReady())
	    {
	      dispatch_sequence();
	    }
	}
    }
  {
    char buf[80];
    sprintf (buf, "Exiting. Total bytes received: %lu.", byte_count);
    print_message (buf);
    CloseComPort();
    _settextwindow (1, 1, NROWS+1, NCOLS);
    _settextposition (NROWS+1, 1);
    _scrolltextwindow (_GSCROLLUP); 
  }
  return 0;
}
